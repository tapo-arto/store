<?php
function tlt_current_url() {
    return home_url( add_query_arg( [], $_SERVER['REQUEST_URI'] ) );
}

add_shortcode( 'tapojarvi_login_tabs', function () {

    $url   = tlt_current_url();
    $err   = '';

    // Tarkistetaan, onko lomake lähetetty ilman sähköpostiosoitetta
    if ( isset($_GET['login']) && $_GET['login'] === 'empty' ) {
        // Virheilmoitus tyhjälle kentälle
        $err = '<div class="login-error">Syötä sähköpostiosoite, jolla olet rekisteröitynyt verkkokauppaan. Jos et ole vielä rekisteröitynyt, tilaa kirjautumislinkki sähköpostiisi Työntekijä välilehdeltä.</div>';
    } elseif ( isset($_GET['login']) && $_GET['login'] === 'failed' ) {
        // Virheilmoitus väärälle tunnukselle
        $err = '<div class="login-error">Väärä käyttäjätunnus tai salasana.</div>';
    }

    ob_start(); ?>
    <div class="tapo-tabs">
        <ul class="tapo-nav">
            <li><a href="#" data-target="tapo-mgr" class="active">Tilausten hallinta</a></li>
            <li><a href="#" data-target="tapo-emp">Työntekijä</a></li>
            <li><a href="#" data-target="tapo-size">Mittalaskuri</a></li>
        </ul>

        <!-- Työmaapäällikkö -->
        <div id="tapo-mgr" class="tapo-pane active">
            <?php echo $err; ?>
            <?php
                // Jos lomake on lähetetty tyhjällä kentällä, estetään ohjaus
                if ( isset($_POST['log']) && empty($_POST['log']) ) {
                    // Älä tee uudelleenohjausta, jos kenttä on tyhjä
                    echo '<script>window.history.replaceState(null, null, "'.esc_url_raw( $url ).'");</script>';
                }
                wp_login_form();
            ?>
        </div>

        <!-- Työntekijä / Magic Link -->
        <div id="tapo-emp" class="tapo-pane">
            <?php echo do_shortcode(
                '[magic_login_form 
                    login-button-text="LÄHETÄ LINKKI" 
                    logout-link-text="Kirjaudu ulos" 
                    redirect_to="' . esc_url( $url ) . '"]'
            ); ?>
        </div>

        <!-- Mittalaskuri -->
        <div id="tapo-size" class="tapo-pane">
            <?php echo do_shortcode('[mittalaskuri]'); ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tarkistetaan lomakkeen lähetys
            const form = document.querySelector('form');
            const emailField = form.querySelector('input[name="log"]');
            const submitButton = form.querySelector('input[type="submit"]');

            form.addEventListener('submit', function(e) {
                if (emailField.value.trim() === '') {
                    e.preventDefault(); // Estetään lomakkeen lähetys
                    alert('Syötä sähköpostiosoite');
                    emailField.focus();
                }
            });
        });
    </script>

    <?php
    return ob_get_clean();
});
