<?php
add_action( 'wp_enqueue_scripts', function () {

    /* CSS */
    wp_enqueue_style(
        'tlt-login-tabs-css',
        plugin_dir_url( __DIR__ ) . 'assets/login-tabs.css',
        [],
        filemtime( plugin_dir_path( __DIR__ ) . 'assets/login-tabs.css' )
    );

    /* JS – ei riippuvuutta jQueryyn */
    wp_enqueue_script(
        'tlt-login-tabs-js',
        plugin_dir_url( __DIR__ ) . 'assets/login-tabs.js',
        [],
        filemtime( plugin_dir_path( __DIR__ ) . 'assets/login-tabs.js' ),
        true   // footer
    );
});
