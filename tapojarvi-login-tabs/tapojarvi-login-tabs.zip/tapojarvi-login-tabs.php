<?php
/*
Plugin Name: Tapojärvi – Login Tabs
Description: Työmaapäällikkö / Työntekijä -kirjautuminen (Magic Link) + mittalaskuri.
 * Author:      Tapojärvi Oy - Arto Huhta
Version: 3.1
*/

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'TLT_DIR', plugin_dir_path( __FILE__ ) );
define( 'TLT_URL', plugin_dir_url( __FILE__ ) );

/* Lataa moduulit */
require_once TLT_DIR . 'includes/shortcodes.php';
require_once TLT_DIR . 'includes/logic.php';
require_once TLT_DIR . 'includes/assets.php';
