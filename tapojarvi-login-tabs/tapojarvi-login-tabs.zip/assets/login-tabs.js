(() => {
    /* ------------------------------------------------------------
     *  Vaihda näkyvää välilehteä
     * ---------------------------------------------------------- */
    const switchTab = id => {
        document.querySelectorAll('.tapo-nav a').forEach(a =>
            a.classList.toggle('active', a.dataset.target === id));

        document.querySelectorAll('.tapo-pane').forEach(p =>
            p.classList.toggle('active', p.id === id));

        localStorage.setItem('tapoActiveTab', id);
    };

    /* ------------------------------------------------------------
     * 1) Navigointipalkin linkit
     * ---------------------------------------------------------- */
    document.addEventListener('click', e => {
        if (!e.target.matches('.tapo-nav a')) return;
        e.preventDefault();
        switchTab(e.target.dataset.target);
    });

    /* ------------------------------------------------------------
     * 2) “Tilaa uusi tästä” -linkki ilmoituksessa
     *    (class="tapo-open-emp")
     * ---------------------------------------------------------- */
    document.addEventListener('click', e => {
        if (!e.target.matches('.tapo-open-emp')) return;
        e.preventDefault();
        switchTab('tapo-emp');
    });

    /* ------------------------------------------------------------
     * 3) Kun DOM on valmis
     * ---------------------------------------------------------- */
    document.addEventListener('DOMContentLoaded', () => {

        /* 3.1  – Jos osoitteessa on #tapo-emp → näytä suoraan se   */
        if (location.hash === '#tapo-emp') {
            switchTab('tapo-emp');
        }

        /* 3.2  – Magic-linkki-viesti aktivoi automaattisesti Emp-välilehden */
        const activeMagic = document.querySelector('#tapo-emp .magic-login-message');
        if (activeMagic) {
            switchTab('tapo-emp');

            /* 3.3  – retry=1 tai virheellinen salasana → oikea tab      */
        } else if (location.search.includes('retry=1')) {
            switchTab('tapo-emp');

        } else if (location.search.includes('login=failed')) {
            switchTab('tapo-mgr');

            /* 3.4  – Muuten viimeksi käytetty tai oletus (mgr)         */
        } else {
            switchTab(localStorage.getItem('tapoActiveTab') || 'tapo-mgr');
        }

        /* 3.5  – Siivotaan query-parametrit pois URL-palkista      */
        if (location.search.includes('login=failed') || location.search.includes('retry=1')) {
            history.replaceState(null, '',
                location.origin + location.pathname + location.hash);
        }

        /* 3.6  – Kuuntelija hash-muutoksille (#tapo-emp jne.)      */
        window.addEventListener('hashchange', () => {
            if (location.hash === '#tapo-emp') {
                switchTab('tapo-emp');
            }
        });

        /* --------------------------------------------------------
         * 4) Domain-tarkistus Esimies / Työntekijä -lomakkeessa
         * ------------------------------------------------------ */
        const magicRoot = document.querySelector('#tapo-emp');
        const emailInput = magicRoot?.querySelector('input[type="email"], input[name="log"]');
        const form = magicRoot?.querySelector('form');
        const domainRE = /@tapojarvi\.(com|fi)$/i;          // -com tai -fi

        if (!emailInput || !form) return;                     // ei lomaketta, ei tarkistusta

        /* 4.1  – Visuaalinen error-boksi */
        const errorBox = document.createElement('div');
        errorBox.className = 'tapo-error';
        errorBox.style.display = 'none';
        magicRoot.prepend(errorBox);

        const showError = msg => {
            errorBox.textContent = msg;
            errorBox.style.display = 'block';
            setTimeout(() => { errorBox.style.display = 'none'; }, 4000);
        };

        emailInput.addEventListener('input', () => {
            errorBox.style.display = 'none';
        });

        /* 4.2  – Hyväksy vain Tapojärvi-sähköpostit */
        form.addEventListener('submit', e => {
            if (!domainRE.test(emailInput.value.trim())) {
                e.preventDefault();
                showError('Syötä @tapojarvi.fi tai @tapojarvi.com osoite.');
            }
        });
    });
})();
