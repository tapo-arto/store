<?php
/**
 * Plugin Name: Tapojärvi Login Tabs
 * Description: Kirjautumis-/rekisteröitymisläpät.
 * Version:     3.1.1
 * Author:      Tapojärvi Oy
 * Text Domain: tapojarvi-login-tabs
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Estä suora pääsy ennen kuin kutsutaan WP-funktioita
}

/** Lataa käännökset /languages-kansiosta */
add_action( 'plugins_loaded', function () {
	load_plugin_textdomain(
		'tapojarvi-login-tabs',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages'
	);
} );

define( 'TLT_DIR', plugin_dir_path( __FILE__ ) );
define( 'TLT_URL', plugin_dir_url( __FILE__ ) );

/** Lataa moduulit turvallisesti */
$includes = [
	'includes/shortcodes.php',
	'includes/logic.php',
	'includes/assets.php',
];

foreach ( $includes as $rel_path ) {
	$abs = TLT_DIR . $rel_path;
	if ( file_exists( $abs ) ) {
		require_once $abs;
	} else {
		// Kirjaa lokiin, ettei tule valkoista ruutua jos tiedosto puuttuu
		error_log( sprintf( '[tapojarvi-login-tabs] Missing include: %s', $abs ) );
	}
}